package com.koddev.chatapp;

public class MyResponse {

    public int success;
}
